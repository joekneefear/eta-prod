# 
# 2017-Feb-02 GMiole - Original.
# 2020-Aug-05 Gmllego - change start and end date DD-MM-YYYY to MM-DD-YYYY. Added support for 2DID as the added parameters. 
# 
package PDF::Parser::ISO;
use strict;
use PDF::DpData;
use PDF::DpLoad;
use PDF::Log;
use File::Basename qw/basename/;
use v5.10;
no warnings qw/experimental::smartmatch experimental::lexical_subs/;

use base qw/PDF::DpData::Base Class::Accessor/;

our $VERSION = "1.0";

my $attr = [];

sub array {
    return qw//;
}

__PACKAGE__->mk_accessors(array);

sub readFile {
    my $self               = shift;
    my $infile             = shift;
    my $retest_flag        = "N";
    my $nothing            = undef;	
    my @parameter          = ();
    my @lolim              = ();
    my @hilim              = ();
    my @unit               = ();
    my $tp     	           = "";
    my $lotno  	           = "";
    my $line               = undef;
    my @values             = ();
    my $tp_rev	           = "";
    my $entity_type        = "";
    my $entity_no          = "";
    my $pf		   = "";
    my $fail_cnt	   = "";
    my $pass_cnt 	   = "";
    my $stp_cnt		   = "";
    my $othr_cnt	   = "";
    my $with_test_readings = 0;	# 0 if none. 1 if available.
    my %binhash            =();
    my %binnamehash        =();
    my $header             = new_headerLong;
    my $wmap               = new_wmap;
    my $model  = new_model(
        {   header => $header,
            wmap   => $wmap,
            misc   => {},
            dataSource => 'ISO'
        }
    );
    my $wafer = new_wafer;
    $model->add( 'wafers', $wafer );
   
    open( INFILE, $infile );
    while ($line=<INFILE>) {
		$line =~ s/\cM\n/\n/g;			
		chomp($line);
		$line  =~ s/^\s+|\s$//g;
		
        ################
        # TEST READINGS
        ################
	if (($line =~ /^\d{1,}\,\s+?\d{1,}\,\s+?\d{2}\//) || ($line =~ /^\d{1,}\,\d{1,}\,\d{2}\//)) 
        {
			my @readings = ();
			my @readings = split /\,/,$line;
			my $readingsLength = scalar(@readings);
			my $id2dResult;
			#INFO("ReadingLenght=>$readingsLength");
			if($readingsLength > 7) {
              $id2dResult = splice(@readings, 3, 1);
			  #INFO("=========2D_ID=$id2dResult");
			  splice(@readings, 6, 0, $id2dResult);
			  #INFO(">>>>@readings<<<<"); 
			}
			
			###print "@readings\n";
			my $no_id      = shift(@readings);
			my $st_no      = shift(@readings);
			my $date_time  = shift(@readings);
			my $test_time  = shift(@readings);
			my $cont_check = shift(@readings);
			my $result     = pop(@readings);
			#INFO("===========>>>>@readings<<<<"); 
			
			if ($result =~/PASS/i){	
			    $pf = 1;
			    $pass_cnt++;
			} elsif ($result =~/FAIL/i){
			    $pf = 2;
			    $fail_cnt++;
			} elsif ($result =~/STOP/i) {
			    $pf = 3;
			    $stp_cnt++;
			} else {
			    $pf = 4;
			    $othr_cnt++;
			}

			### SKIP UNIT DATA IF NO PASS/FAIL FLAG ###
			next if $#readings == -1;
			
			### CONVERT TEST READINGS TO BASE UNIT ###
			my $die = new_die;
			$die->partid($no_id);
			$die->site( $st_no );
			$die->soft_bin( $pf );
			$die->hard_bin( $pf );
			for (my $i=0; $i<=$#parameter; $i++)
              {
				#INFO("====RESULT=$readings[$i]");
				if($i <= $#readings){
					 #INFO("====RESULT=$readings[$i]");
					 $die->add('result',$readings[$i]);
				}else{
					 $die->add('result',"N/A");
				}
                        }
			$with_test_readings = 1;
                        $wafer->add( 'dies', $die );
	}
	#################
        # PARAMETER NAME 
        #################
        elsif ($line =~ /^No\,ST\,\s+Date/i)
        {
            @parameter = split /\,/, $line;
			my $parametersLength = scalar(@parameter);
			#INFO("parametersLength=>$parametersLength");
			my $id2dParamName;
			if($parametersLength > 7) {
              $id2dParamName = splice(@parameter, 3, 1);
			  #INFO("@parameter)=====2D_ID_Param=$id2dParamName");
			  splice(@parameter, 6, 0, $id2dParamName);
			  #INFO(">>>>=======@parameter=====<<<<");
			}

            shift(@parameter);                       #<-- REMOVES THE "No"         WORD
            shift(@parameter);                       #<-- REMOVES THE "ST"         WORD
            shift(@parameter);                       #<-- REMOVES THE "Date Time"  WORD
            shift(@parameter);                       #<-- REMOVES THE "Test Time"  WORD
            shift(@parameter);                       #<-- REMOVES THE "CONT CHECK" WORD
            pop(@parameter);                       #<-- REMOVES THE "RESULT    " WORD
			#INFO("===========>>>>@parameter<<<<");
        }
	##############
        # LOWER LIMIT
        ##############
        elsif ($line =~ /LOW\s+LIMIT/i)
        {
            @lolim = split /\,/, $line;
			my $lolimLength = scalar(@lolim);
			#INFO("lolimLength=>$lolimLength");
			my $lolim;
			if($lolimLength > 7) {
              $lolim = splice(@lolim, 3, 1);
			  #INFO("==============lolim=$lolim");
			  splice(@lolim, 6, 0, $lolim);
			  #INFO(">>>>@lolim<<<<");
			}
            shift(@lolim);                           #<-- REMOVES THE " "         WORD
            shift(@lolim);                           #<-- REMOVES THE " "         WORD
            shift(@lolim);                           #<-- REMOVES THE "LOW LIMIT" WORD
            shift(@lolim);                           #<-- REMOVES THE " "         WORD
            shift(@lolim);                           #<-- REMOVES THE "0x0000000" WORD
            pop(@lolim);                           #<-- REMOVES THE " "         WORD
			#INFO(">>>>@lolim<<<<");
        }
	##############
        # UPPER LIMIT
        ##############
        elsif ($line =~ /HIGH\s+LIMIT/i)
        {
            @hilim = split /\,/, $line;
			my $hilimLength = scalar(@hilim);
			#INFO("hilimLength=>$hilimLength");
			my $hilim;
			if($hilimLength > 7) {
              $hilim = splice(@hilim, 3, 1);
			  #INFO("===================hilim=$hilim");
			  splice(@hilim, 6, 0, $hilim);
			  #INFO(">>>>@hilim<<<<");
			}
            shift(@hilim);                           #<-- REMOVES THE " "          WORD
            shift(@hilim);                           #<-- REMOVES THE " "          WORD
            shift(@hilim);                           #<-- REMOVES THE "HIHG LIMIT" WORD
            shift(@hilim);                           #<-- REMOVES THE " "          WORD
            shift(@hilim);                           #<-- REMOVES THE "0x00000000" WORD
              pop(@hilim);                           #<-- REMOVES THE " "          WORD
			  #INFO(">>>>@hilim<<<<");
        }
        #############
	# TEST UNITS
	#############
	elsif ($line =~ /UNIT/i)
	{
	    @unit = split /\,/, $line;
		my $unitLength = scalar(@unit);
		#INFO("unitLength=>$unitLength");
		my $unit;
		if($unitLength > 7) {
           $unit = splice(@unit, 3, 1);
		   #INFO("================UNIT=>>$unit<<");
		   splice(@unit, 6, 0, $unit);
		  #INFO(">>>>@unit<<<<");
		}
  	    shift(@unit);			     #<-- REMOVES " "    WORD
  	    shift(@unit);			     #<-- REMOVES " "    WORD
  	    shift(@unit);			     #<-- REMOVES "UNIT" WORD
  	    shift(@unit);			     #<-- REMOVES "S"    WORD
  	    shift(@unit);			     #<-- REMOVES " "    WORD
  	    pop(@unit);			     #<-- REMOVES " "    WORD
		  #INFO(">>>>@unit<<<<");


			############################# 
			# STORE TESTPLAN INTO A HASH
			#############################
			for(my $i=0; $i<=$#parameter; $i++)
			{
				$parameter[$i] =~ s/ //g;
				$hilim[$i]     =~ s/ //g;
				$lolim[$i]     =~ s/ //g;
				$unit[$i]      =~ s/\s|\-//g;	
				#INFO(">>>>>>>>>>>>PARAM=$parameter[$i]||HILIM=$hilim[$i]||LOLIM=$lolim[$i]||UNIT=$unit[$i]");
				my $test_num = $i+1;
				my $test = new_test;
				$test->number( $test_num );
				$test->name( uc(trim($parameter[$i])));
				$test->units($unit[$i]);
				$test->LSL($lolim[$i]);
				$test->HSL($hilim[$i]);
				$wafer->add('tests', $test );

			}
	}
        elsif ( $line =~ /HOST/i ) {
                my ($dummy, $entity) = split /\:/, $line;
                #print"$entity\n";
		$header->EQUIP1_ID($entity);
        }
	###########
	# TESTPLAN
	###########	
        if ( $line =~ /Program/i) {
	     my ($dummy, $test_plan)    = split /\:/, $line;
	     $tp = $test_plan;
             $tp =~ s/[^0-9A-Z\-\_]//g;
             $header->PROGRAM($tp);
        }
	###########
	# Revision 
	###########	
        if ( $line =~ /Version/i) {
	     my ($dummy, $tp_rev)    = split /\:/, $line;
             $header->REVISION($tp_rev);
        }
	########
	# LOTNO
	########
	elsif ($line =~ /LotNo/i)
	{
	    my ($dummy, $lotid)    = split /\:/, $line;
	        $lotno       = $lotid;
		$lotno       =~ s/[^a-zA-Z0-9]//g;
	        $lotno       =~ s/AO/A0/ig;
	        $lotno       =~ s/XO/X0/ig;
		$retest_flag = "Y" if $lotno=~/REJ/i || $infile=~/REJ/i; ### CHECK IF RETEST DATA
		$lotno       =~ s/REJ//gi;
		$lotno       = substr($lotno,0,10) if length($lotno) > 10 && $lotno =~ /^A/i;
		$header->LOT(uc($lotno));
                ###print "lotno=$lotno\n";
        }
	###################
        # TEST DATE & TIME
        ###################
        elsif ($line =~ /Test\s+Start/i)
        {
        	my ($dummy, $test_start) = split /\.\.\s+/, $line;
		    $test_start =~ s/^\s+|\s$//g;
		    $test_start =~ s/\s+/ /g;
			$test_start = formatDate($test_start);
		    $header->START_TIME($test_start);
        }
        elsif ($line =~ /Test\s+End/i)
        {
        	my ($dummy, $test_end) = split /\.\.\s+/, $line;
		    $test_end =~ s/^\s+|\s$//g;
		    $test_end =~ s/\s+/ /g;
			$test_end = formatDate($test_end);
		    $header->END_TIME($test_end);
        }
	 	
    }

	for(1..4)
	{
	   my $hbin = new_bin;
	   if ($_ ==1) {
               $hbin->number(1);
	       $hbin->name("PASS");
	       $hbin->PF("P");
	       $hbin->count($pass_cnt);
	   } elsif ($_ ==2) {
               $hbin->number(2);
	       $hbin->name("FAIL");
	       $hbin->PF("F");
	       $hbin->count($fail_cnt);
	   } elsif ($_ ==3) {
               $hbin->number(3);
	       $hbin->name("STOP");
	       $hbin->PF("F");
	       $hbin->count($stp_cnt);
	   } else {
               $hbin->number(4);
	       $hbin->name("OTHER");
	       $hbin->PF("F");
	       $hbin->count($othr_cnt);
	   }
	   $wafer->add('hbins',$hbin);
	}

    close(INFILE);
    ###################################
    # TRAP EMPTY LOTID & TESTPLAN NAME
    ###################################
    if ($lotno eq "")
    {
        dpExit(1, "no_lotid in file");
    }
	elsif ($tp eq "")
	{
		dpExit(1, "missing testplan in file");
	}
	### MUST HAVE TEST READINGS ###
	if ($with_test_readings == 0)
	{
		dpExit(1, "no_part_data in file");
	}
    return $model;
}
1;
