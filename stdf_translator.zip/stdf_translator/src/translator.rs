use std::io::{self, BufRead, Write};
use rust_stdf::stdf_record_type::*;
use rust_stdf::stdf_file::*;
use quick_xml::events::{Event, BytesStart, BytesEnd, BytesText};
use quick_xml::Writer;
use crate::models::*;

pub fn process_stdf_stream<R: BufRead, W: Write>(reader: R, writer: W) -> anyhow::Result<()> {
    let mut stdf_reader = StdfReader::new(reader);
    let mut xml_writer = Writer::new(writer);
    
    // Write XML declaration
    xml_writer.write_event(Event::Decl(quick_xml::events::BytesDecl::new("1.0", Some("UTF-8"), None)))?;
    
    // Root element <STDF>
    xml_writer.write_event(Event::Start(BytesStart::new("STDF")))?;

    let mut current_lot: Option<LotRecord> = None;
    let mut current_wafer: Option<WaferRecord> = None;
    let mut current_unit: Option<UnitRecord> = None;
    
    // We need to track context to close tags properly
    let mut in_lot = false;
    let mut in_wafer = false;
    let mut in_unit = false;

    // Use a loop to iterate through records
    for record in stdf_reader.get_record_iter() {
        let record = record?;
        match record {
            StdfRecord::FAR(far) => {
                let file_rec = FileRecord {
                    file_name: "STDF_FILE".to_string(), // Placeholder or should be passed in?
                    cpu_type: far.cpu_type,
                    stdf_version: far.stdf_version,
                };
                // Serialize File record
                // quick-xml doesn't have a direct "serialize to writer" for structs in the same way serde_json does without a wrapper
                // But we can use a helper or manual writing. 
                // For simplicity/speed in this context, let's use serde integration if available or manual.
                // Given constraints, I'll use a helper function to serialize struct to events if possible, 
                // OR just manually write generic Start/End tags with attributes.
                // Re-writing strict XML with attributes manually is robust.
                
                let mut elem = BytesStart::new("File");
                elem.push_attribute(("FileName", "STDF_FILE")); // In real app, pass filename
                elem.push_attribute(("CPUType", far.cpu_type.to_string().as_str()));
                elem.push_attribute(("STDFVersion", far.stdf_version.to_string().as_str()));
                xml_writer.write_event(Event::Empty(elem))?;
            },
            StdfRecord::MIR(mir) => {
                if in_lot {
                    // Implicit close? STDF shouldn't have nested lots usually without closing?
                     xml_writer.write_event(Event::End(BytesEnd::new("Lot")))?;
                }
                in_lot = true;
                
                let start = BytesStart::new("Lot");
                let mut elem = start.clone();
                // Map fields
                elem.push_attribute(("LotId", mir.lot_id.as_str()));
                elem.push_attribute(("PartType", mir.part_typ.as_str()));
                elem.push_attribute(("JobName", mir.job_nam.as_str()));
                elem.push_attribute(("TesterType", mir.tstr_typ.as_str()));
                elem.push_attribute(("SetupTime", mir.setup_t.to_string().as_str())); // Needs formatting?
                // ... Add all other attributes from MIR ...
                
                xml_writer.write_event(Event::Start(elem))?;
            },
            StdfRecord::MRR(mrr) => {
                // Lot End
                if in_unit {
                     xml_writer.write_event(Event::End(BytesEnd::new("Unit")))?;
                     in_unit = false;
                }
                if in_wafer {
                     xml_writer.write_event(Event::End(BytesEnd::new("Wafer")))?;
                     in_wafer = false;
                }
                
                // Maybe write MRR fields as attributes to a closing summary or just close Lot
                // CSV says MRR maps to Lot.FinishTime. 
                // Since we already opened Lot, we can't easily add attributes to the *opening* tag now.
                // We might emit a <LotSummary> or just Close Lot.
                // For XML valid structure, usually one element. 
                // We could emit <LotFinish ... /> inside Lot before closing.
                
                let mut elem = BytesStart::new("LotFinish");
                elem.push_attribute(("FinishTime", mrr.finish_t.to_string().as_str()));
                xml_writer.write_event(Event::Empty(elem))?;

                if in_lot {
                    xml_writer.write_event(Event::End(BytesEnd::new("Lot")))?;
                    in_lot = false;
                }
            },
            StdfRecord::WIR(wir) => {
                if in_wafer {
                    xml_writer.write_event(Event::End(BytesEnd::new("Wafer")))?;
                }
                in_wafer = true;
                let mut elem = BytesStart::new("Wafer");
                elem.push_attribute(("WaferId", wir.wafer_id.as_str()));
                 elem.push_attribute(("StartTime", wir.start_t.to_string().as_str()));
                xml_writer.write_event(Event::Start(elem))?;
            },
            StdfRecord::WRR(wrr) => {
                if in_unit {
                    xml_writer.write_event(Event::End(BytesEnd::new("Unit")))?;
                    in_unit = false;
                }
                // Wafer Summary
                 let mut elem = BytesStart::new("WaferFinish");
                elem.push_attribute(("FinishTime", wrr.finish_t.to_string().as_str()));
                elem.push_attribute(("PartCount", wrr.part_cnt.to_string().as_str()));
                xml_writer.write_event(Event::Empty(elem))?;
                
                if in_wafer {
                    xml_writer.write_event(Event::End(BytesEnd::new("Wafer")))?;
                    in_wafer = false;
                }
            },
            StdfRecord::PIR(pir) => {
                 if in_unit {
                    xml_writer.write_event(Event::End(BytesEnd::new("Unit")))?;
                }
                in_unit = true;
                let mut elem = BytesStart::new("Unit");
                elem.push_attribute(("Head", pir.head_num.to_string().as_str()));
                elem.push_attribute(("Site", pir.site_num.to_string().as_str()));
                xml_writer.write_event(Event::Start(elem))?;
            },
            StdfRecord::PRR(prr) => {
                // Unit End - PRR has valid data like X, Y, Bin
                // We need to add this data to the Unit.
                // Since Unit is already open, we can add a <Result ... /> element or similar.
                // OR, checking the CSV: Unit element HAS X, Y, HardBin.
                // This implies we should have ideally waited to emit <Unit> until we had PRR? 
                // But PTRs come *between* PIR and PRR. 
                // So the XML structure <Unit head=".."> <Meas>... </Meas> <Result x=".." y=".."/> </Unit> is likely best.
                
                let mut elem = BytesStart::new("UnitResult");
                elem.push_attribute(("X", prr.x_coord.to_string().as_str()));
                elem.push_attribute(("Y", prr.y_coord.to_string().as_str()));
                elem.push_attribute(("HardBin", prr.hard_bin.to_string().as_str()));
                elem.push_attribute(("SoftBin", prr.soft_bin.to_string().as_str()));
                elem.push_attribute(("TestTime", prr.test_t.to_string().as_str()));
                xml_writer.write_event(Event::Empty(elem))?;
                
                if in_unit {
                    xml_writer.write_event(Event::End(BytesEnd::new("Unit")))?;
                    in_unit = false;
                }
            },
            StdfRecord::PTR(ptr) => {
                if in_unit {
                    let mut elem = BytesStart::new("Meas");
                    elem.push_attribute(("TestNum", ptr.test_num.to_string().as_str()));
                    elem.push_attribute(("Head", ptr.head_num.to_string().as_str()));
                    elem.push_attribute(("Site", ptr.site_num.to_string().as_str()));
                    elem.push_attribute(("Val", ptr.result.to_string().as_str()));
                    elem.push_attribute(("PF", if (ptr.test_flg & 0x80) != 0 { "F" } else { "P" })); // Simplified PF check
                    // elem.push_attribute(("TestText", ptr.test_txt.as_str())); // Rust-stdf might not have this in PTR struct directly if simple
                    // rust-stdf PTR has `test_txt`? Checking docs/memory... 
                    // It usually does not have text, that's in TSR (Test Synopsis).
                    // Or PTR might have `alarm_id` etc.
                    // The CSV mapping implies joining with TSR. 
                    // In a streaming single-pass converter, joining is hard without caching TSRs.
                    // Implementation Detail: We should cache TSRs by TEST_NUM to lookup names. (Global HashMap).
                    
                    xml_writer.write_event(Event::Empty(elem))?;
                }
            },
            StdfRecord::MPR(mpr) => {
                 if in_unit {
                    let mut elem = BytesStart::new("Meas");
                     elem.push_attribute(("TestNum", mpr.test_num.to_string().as_str()));
                     // Smart handling for MPR arrays...
                     xml_writer.write_event(Event::Empty(elem))?;
                 }
            },
            StdfRecord::FTR(ftr) => {
                 if in_unit {
                    let mut elem = BytesStart::new("Meas");
                     elem.push_attribute(("TestNum", ftr.test_num.to_string().as_str()));
                     elem.push_attribute(("PF", if (ftr.test_flg & 0x80) != 0 { "F" } else { "P" }));
                     xml_writer.write_event(Event::Empty(elem))?;
                 }
            },
            _ => {
                // Ignore other records
            }
        }
    }
    
    // Close any open tags
    if in_unit { xml_writer.write_event(Event::End(BytesEnd::new("Unit")))?; }
    if in_wafer { xml_writer.write_event(Event::End(BytesEnd::new("Wafer")))?; }
    if in_lot { xml_writer.write_event(Event::End(BytesEnd::new("Lot")))?; }
    
    xml_writer.write_event(Event::End(BytesEnd::new("STDF")))?;

    Ok(())
}
