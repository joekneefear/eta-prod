use std::io::{Read, Write, Result as IoResult, Error as IoError, ErrorKind, Cursor};
use std::sync::mpsc::{Receiver, SyncSender};
use bytes::{Bytes, BytesMut};
use tokio::sync::mpsc::Sender as TokioSender;

// --- Input Pipe: Channel -> Read ---

pub struct ChannelReader {
    receiver: Receiver<Bytes>,
    current_chunk: Option<Cursor<Bytes>>,
}

impl ChannelReader {
    pub fn new(receiver: Receiver<Bytes>) -> Self {
        Self { receiver, current_chunk: None }
    }
}

impl Read for ChannelReader {
    fn read(&mut self, buf: &mut [u8]) -> IoResult<usize> {
        loop {
            if let Some(cursor) = &mut self.current_chunk {
                let n = cursor.read(buf)?;
                if n > 0 {
                    return Ok(n);
                }
            }
            // Current chunk parsing finished or empty, get next
            match self.receiver.recv() {
                Ok(bytes) => self.current_chunk = Some(Cursor::new(bytes)),
                Err(_) => return Ok(0), // Channel closed, EOF
            }
        }
    }
}

// --- Output Pipe: Write -> Tokio Channel ---

pub struct ChannelWriter {
    sender: TokioSender<IoResult<Bytes>>,
}

impl ChannelWriter {
    pub fn new(sender: TokioSender<IoResult<Bytes>>) -> Self {
        Self { sender }
    }
}

impl Write for ChannelWriter {
    fn write(&mut self, buf: &[u8]) -> IoResult<usize> {
        let bytes = Bytes::copy_from_slice(buf);
        // We use blocking send because this runs in a blocking thread
        match self.sender.blocking_send(Ok(bytes)) {
            Ok(_) => Ok(buf.len()),
            Err(_) => Err(IoError::new(ErrorKind::BrokenPipe, "Output channel closed")),
        }
    }

    fn flush(&mut self) -> IoResult<()> {
        Ok(())
    }
}
