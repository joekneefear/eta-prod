use axum::{
    extract::{Multipart, DefaultBodyLimit},
    response::{IntoResponse, Response, Html},
    routing::{post, get},
    Router,
    body::Body,
};
use tokio_util::io::ReaderStream;
use futures::stream::StreamExt;
use std::io::{BufReader, BufWriter};
use std::fs::File;
use std::net::SocketAddr;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
use clap::Parser;
use std::time::Instant;
use std::sync::mpsc;

mod models;
mod translator;
mod stream_utils;
use stream_utils::{ChannelReader, ChannelWriter};

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Start the web server
    #[arg(short, long)]
    server: bool,

    /// Input STDF file for CLI mode
    #[arg(short, long)]
    input: Option<String>,

    /// Output XML file for CLI mode
    #[arg(short, long)]
    output: Option<String>,
}

const INDEX_HTML: &str = r#"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STDF to XML Translator</title>
    <!-- Styles same as before -->
    <style>
        :root { --primary: #007bff; --bg: #f8f9fa; --surface: #ffffff; --border: #dee2e6; --text: #212529; --code-tag: #aa0000; --code-attr: #2a7bb6; --code-val: #008000; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; background: var(--bg); color: var(--text); }
        h1 { text-align: center; color: var(--primary); margin-bottom: 30px; }
        
        .upload-container { border: 2px dashed var(--primary); padding: 40px; text-align: center; background: var(--surface); border-radius: 12px; transition: all 0.2s; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .upload-container:hover, .upload-container.dragover { background: #e9ecef; border-color: #0056b3; transform: translateY(-2px); }
        input[type="file"] { display: none; }
        .btn { background: var(--primary); color: white; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; display: inline-block; transition: background 0.2s; }
        .btn:hover { background: #0056b3; }
        
        .stats-panel { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; display: none; }
        .stat-card { background: var(--surface); padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid var(--primary); }
        .stat-val { font-size: 1.5em; font-weight: bold; color: var(--primary); }
        .stat-label { color: #6c757d; font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.5px; }

        .viewer-container { background: var(--surface); border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); overflow: hidden; margin-top: 20px; display: none; border: 1px solid var(--border); }
        .viewer-header { background: #f1f3f5; padding: 10px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .viewer-actions button { background: none; border: 1px solid var(--border); padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 0.85em; background: white; }
        .viewer-actions button:hover { background: #f8f9fa; }
        .xml-content { padding: 20px; overflow-x: auto; font-family: 'Consolas', 'Monaco', monospace; font-size: 13px; line-height: 1.5; max-height: 600px; overflow-y: auto; }
        
        details { margin-left: 20px; }
        summary { cursor: pointer; list-style: none; color: var(--code-tag); font-weight: bold; outline: none; }
        summary::-webkit-details-marker { display: none; }
        summary::before { content: '▶'; display: inline-block; font-size: 0.7em; margin-right: 5px; color: #666; transition: transform 0.2s; }
        details[open] > summary::before { transform: rotate(90deg); }
        .tag-name { color: #881280; }
        .attr-name { color: #994500; }
        .attr-val { color: #1a1aa6; }
        .leaf-node { margin-left: 24px; color: var(--text); }
        
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid var(--primary); border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 20px auto; display: none; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <h1>STDF to XML Translator</h1>
    
    <div class="upload-container" id="drop-zone">
        <div style="font-size: 3em; color: #dee2e6; margin-bottom: 10px;">📂</div>
        <p style="font-size: 1.2em; margin-bottom: 20px;">Drag & Drop STDF file here</p>
        <label for="file-upload" class="btn">Browse Files</label>
        <input id="file-upload" type="file" accept=".stdf,.std">
        <p id="file-name" style="margin-top: 15px; font-weight: 500;"></p>
        <div id="spinner" class="spinner"></div>
    </div>

    <div id="stats-panel" class="stats-panel">
        <div class="stat-card">
            <div class="stat-val" id="stat-size">0 MB</div>
            <div class="stat-label">File Size</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" id="stat-time">0 ms</div>
            <div class="stat-label">Total Time</div>
        </div>
        <div class="stat-card">
            <div class="stat-val" id="stat-rx">0 MB</div>
            <div class="stat-label">XML Received</div>
        </div>
    </div>

    <div id="viewer-container" class="viewer-container">
        <div class="viewer-header">
            <strong>XML Preview</strong>
            <div class="viewer-actions">
                <button onclick="downloadXML()">Download File</button>
            </div>
        </div>
        <div id="xml-content" class="xml-content"></div>
    </div>

    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const fileNameDisplay = document.getElementById('file-name');
        const statsPanel = document.getElementById('stats-panel');
        const viewerContainer = document.getElementById('viewer-container');
        const xmlContent = document.getElementById('xml-content');
        const spinner = document.getElementById('spinner');

        let currentXMLBlob = null;
        let currentFileName = "";

        dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
        dropZone.addEventListener('dragleave', (e) => { e.preventDefault(); dropZone.classList.remove('dragover'); });
        dropZone.addEventListener('drop', (e) => { e.preventDefault(); dropZone.classList.remove('dragover'); handleFile(e.dataTransfer.files[0]); });
        fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));

        function handleFile(file) {
            if (!file) return;
            currentFileName = file.name;
            fileNameDisplay.textContent = file.name;
            uploadFile(file);
        }

        async function uploadFile(file) {
            spinner.style.display = "block";
            statsPanel.style.display = "none";
            viewerContainer.style.display = "none";
            xmlContent.innerHTML = "";
            
            const formData = new FormData();
            formData.append("file", file);

            const startTime = performance.now();

            try {
                const response = await fetch('/convert', { method: 'POST', body: formData });
                
                if (!response.ok) throw new Error(await response.text());
                
                // Show input size immediately
                const inputSize = file.size;
                document.getElementById('stat-size').textContent = formatBytes(inputSize);
                statsPanel.style.display = "grid";

                const reader = response.body.getReader();
                let receivedLength = 0;
                let chunks = [];
                
                while(true) {
                    const {done, value} = await reader.read();
                    if (done) break;
                    chunks.push(value);
                    receivedLength += value.length;
                    document.getElementById('stat-rx').textContent = formatBytes(receivedLength);
                }
                
                const endTime = performance.now();
                const duration = Math.round(endTime - startTime);
                document.getElementById('stat-time').textContent = duration + " ms";

                // Combine chunks
                currentXMLBlob = new Blob(chunks, {type: 'application/xml'});
                const text = await currentXMLBlob.text();
                
                viewerContainer.style.display = "block";
                renderXMLTree(text);

            } catch (error) {
                alert("Error: " + error.message);
            } finally {
                spinner.style.display = "none";
            }
        }

        function formatBytes(bytes, decimals = 2) {
            if (!+bytes) return '0 Bytes';
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
        }

        // ... existing XML Tree functions ...
        function renderXMLTree(xmlString) {
             const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlString, "text/xml");
            if (xmlDoc.getElementsByTagName("parsererror").length > 0) {
                xmlContent.textContent = "Error parsing XML for preview.";
                return;
            }
            const fragment = document.createDocumentFragment();
            fragment.appendChild(createNode(xmlDoc.documentElement));
            xmlContent.appendChild(fragment);
        }

        function createNode(node) {
            if (node.nodeType === Node.ELEMENT_NODE) {
                const details = document.createElement('details');
                details.open = true;
                const summary = document.createElement('summary');
                const tagName = document.createElement('span');
                tagName.className = 'tag-name';
                tagName.textContent = `<${node.tagName}`;
                summary.appendChild(tagName);
                Array.from(node.attributes).forEach(attr => {
                    const attrName = document.createElement('span');
                    attrName.className = 'attr-name';
                    attrName.textContent = ` ${attr.name}=`;
                    const attrVal = document.createElement('span');
                    attrVal.className = 'attr-val';
                    attrVal.textContent = `"${attr.value}"`;
                    summary.appendChild(attrName);
                    summary.appendChild(attrVal);
                });
                const closeTag = document.createElement('span');
                closeTag.className = 'tag-name';
                if (node.childNodes.length === 0) {
                    closeTag.textContent = ` />`;
                    summary.appendChild(closeTag);
                    details.appendChild(summary);
                    const div = document.createElement('div');
                    div.className = 'leaf-node';
                    div.style.marginLeft = "20px";
                    div.appendChild(summary.cloneNode(true));
                    return div;
                } 
                closeTag.textContent = `>`;
                summary.appendChild(closeTag);
                details.appendChild(summary);
                Array.from(node.childNodes).forEach(child => {
                     details.appendChild(createNode(child));
                });
                const endTag = document.createElement('div');
                endTag.className = 'tag-name';
                endTag.style.marginLeft = '23px';
                endTag.textContent = `</${node.tagName}>`;
                details.appendChild(endTag);
                return details;
            } else if (node.nodeType === Node.TEXT_NODE) {
                if (node.nodeValue.trim() === "") return document.createDocumentFragment();
                const div = document.createElement('div');
                div.className = 'leaf-node';
                div.textContent = node.nodeValue;
                return div;
            }
            return document.createDocumentFragment();
        }

        function downloadXML() {
             if (!currentXMLBlob) return;
            const url = window.URL.createObjectURL(currentXMLBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = currentFileName + ".xml";
            document.body.appendChild(a);
            a.click();
            a.remove();
        }
    </script>
</body>
</html>
"#;

#[tokio::main]
async fn main() {
    tracing_subscriber::registry()
        .with(tracing_subscriber::EnvFilter::parse("info,stdf_translator=debug"))
        .with(tracing_subscriber::fmt::layer())
        .init();

    let args = Args::parse();

    if args.server {
        run_server().await;
    } else if let Some(input_path) = args.input {
        run_cli(input_path, args.output);
    } else {
        use clap::CommandFactory;
        let mut cmd = Args::command();
        cmd.print_help().unwrap();
    }
}

async fn run_server() {
    let app = Router::new()
        .route("/", get(index_handler))
        .route("/convert", post(convert_stdf_web))
        // Important: Increase body limit for streaming mostly affects if we buffer, but we stream now.
        // But Axum multipart limit still applies per field.
        .layer(DefaultBodyLimit::max(1024 * 1024 * 1024 * 5)); // 5GB limit

    let addr = SocketAddr::from(([127, 0, 0, 1], 3000));
    tracing::info!("Server listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn index_handler() -> Html<&'static str> {
    Html(INDEX_HTML)
}

fn run_cli(input_path: String, output_path: Option<String>) {
    // CLI logic doesn't leverage the fancy pipe utils since File is already Sync Read/Write
    // and we blocking in main thread.
    tracing::info!("Starting CLI conversion for {}", input_path);
    let start = Instant::now();
    
    let input_file = match File::open(&input_path) {
        Ok(f) => f,
        Err(e) => {
            tracing::error!("Failed to open input file: {}", e);
            return;
        }
    };
    let reader = BufReader::new(input_file);

    if let Some(out_path) = output_path {
        let output_file = match File::create(&out_path) {
            Ok(f) => f,
            Err(e) => {
                tracing::error!("Failed to create output file: {}", e);
                return;
            }
        };
        let writer = BufWriter::new(output_file);
        
        match translator::process_stdf_stream(reader, writer) {
            Ok(_) => {
                let duration = start.elapsed();
                tracing::info!("Conversion successful. Saved to {}. Time: {:?}", out_path, duration);
            },
            Err(e) => tracing::error!("Conversion failed: {}", e),
        }
    } else {
        let writer = std::io::stdout();
        match translator::process_stdf_stream(reader, writer) {
             Ok(_) => {}, 
             Err(e) => tracing::error!("Conversion failed: {}", e),
        }
    }
}

async fn convert_stdf_web(mut multipart: Multipart) -> Response {
    while let Some(field) = multipart.next_field().await.unwrap() {
        let name = field.name().unwrap().to_string();
        if name == "file" {
            // --- Streaming Pipeline Setup ---
            
            // 1. Input Channel: Async Part -> Sync Reader
            // Allow buffer to avoid too many context switches. 64KB chunks?
            // Axum yields chunks. 
            // mpsc channel size 16 = 16 chunks.
            // Use std::sync::mpsc for Sync Reader.
            let (tx_in, rx_in) = mpsc::sync_channel(16);
            
            // 2. Output Channel: Sync Writer -> Async Stream
            // Use tokio::sync::mpsc for Async Stream.
            let (tx_out, rx_out) = tokio::sync::mpsc::channel(16);
            
            // 3. Spawn Blocking Translator Task
            tokio::task::spawn_blocking(move || {
                let reader = stream_utils::ChannelReader::new(rx_in);
                let writer = stream_utils::ChannelWriter::new(tx_out);
                // Also wrap in BufWriter to chunk writes nicely
                let mut buf_writer = BufWriter::with_capacity(64 * 1024, writer);
                
                if let Err(e) = translator::process_stdf_stream(reader, &mut buf_writer) {
                    tracing::error!("Streaming translation failed: {}", e);
                }
                // Implicit drop of tx_out signals EOF to stream
            });
            
            // 4. Spawn Async Input Feeder
            tokio::spawn(async move {
                while let Ok(Some(chunk)) = field.chunk().await {
                   if let Err(_) = tx_in.send(chunk) {
                       break; // Reader closed
                   }
                }
                // tx_in drop signals EOF to reader
            });
            
            // 5. Create Response Stream from Output Channel
            let stream = tokio_stream::wrappers::ReceiverStream::new(rx_out);
            let body = Body::from_stream(stream);
            
            return Response::builder()
                .header(axum::http::header::CONTENT_TYPE, "application/xml")
                .body(body)
                .unwrap();
        }
    }
    (axum::http::StatusCode::BAD_REQUEST, "No file found").into_response()
}

#[cfg(test)]
mod tests {
    use super::*;
    // Existing tests...
}
